using UnityEngine;


public class doorspawner : MonoBehaviour
{
    public Transform doorpivot;
    public Transform door;
    public float mindoorsize = 1f;
    public float maxdoorsize = 3f;
    private Vector3 originalDoorScale;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
       
        originalDoorScale = door.localScale;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void spawn()
    {

//random angle spawn ka lia 
        float randomAngle = Random.Range(0f, 360f);

        doorpivot.rotation = Quaternion.Euler(0f, 0f, randomAngle);
        //random size ka lia door ka 
        float randomSize = Random.Range(mindoorsize, maxdoorsize);

        door.localScale = new Vector3(originalDoorScale.x ,originalDoorScale.y*randomSize,originalDoorScale.z);
    }
}
