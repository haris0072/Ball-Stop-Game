using UnityEngine;

public class rotate : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public gemlogic checking;
    public float rotatespeed=200f;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (checking.timing == true)
        {
            transform.Rotate(0, 0, rotatespeed * Time.deltaTime);
        }
    }
}
