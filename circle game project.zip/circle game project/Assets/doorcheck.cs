using UnityEngine;
public class doorcheck : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public bool chekdoor = false;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("ball"))
        {
            chekdoor = true;
            Debug.Log("in");
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("ball"))
        {
            chekdoor = false;
            Debug.Log("out");
        }
    }
}
