using System.Threading;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
public class gemlogic : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public Text timetext;
    public GameObject button;
    public GameObject anotherbutton;
    public float Timer =30f;
    public bool timing = true;
    public Text scoretext;
    public doorcheck doorcheck;
    public int totalscore = 0;
    public int combo = 0;
    public doorspawner spawn;
    void Start()
    {
        scoretext.text = "0";
        timetext.text = "30";
    }

    // Update is called once per frame
    void Update()
    {
        if (timing == true)
        {
            Timer -= Time.deltaTime;
            timetext.text = Mathf.Ceil(Timer).ToString();
            if (Timer <= 0)
            {
                timing = false;
                timetext.text = "0";
                button.SetActive(true);
                anotherbutton.SetActive(true);
                Debug.Log("Game Over");
            }
        }

        if (timing == true && Input.GetKeyDown(KeyCode.Space))
        {
            // Debug.Log("check");
            MobileInput();
        }
    }
    public void MobileInput()
    {
        if (timing == true)
        {
            // Debug.Log("check");
           
            if (doorcheck.chekdoor == true)
            {
                combo++;
                spawn.spawn();
                if (combo >= 5)
                {
                    combo = 5;
                }

                totalscore += combo;
                scoretext.text = totalscore.ToString();
                Debug.Log("Score: " + totalscore + " Combo: " + combo);

            }
            else
            {
                combo = 0;
                Debug.Log("reset");
            }
        }
        
    }

}
