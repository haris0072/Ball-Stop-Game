using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class uibutton : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public GameObject button;
    public GameObject anotherbutton; 
    void Start()
    {
        Time.timeScale = 0f;
        anotherbutton.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void pausebutton()
    {
        button.SetActive(true);
        Time.timeScale=0f;
    }
    public void resumebutton()
    {
        button.SetActive(false);
        Time.timeScale=1f;

    }
    public void restartbutton()
    {
      
        anotherbutton.SetActive(false);
        Time.timeScale = 1f;
    }
    public void restartgame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void quit()
    {
        
        Application.Quit();
    }

}
